using TMPro;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.UI;

public class EnterUI : MonoBehaviour
{
    [SerializeField] private TMP_InputField ipInput;
    [SerializeField] private Button hostButton;
    [SerializeField] private Button clientButton;

    private void Awake()
    {
        hostButton.onClick.AddListener(HandleHostStartEvent);
        clientButton.onClick.AddListener(HandleClientStartEvent);
    }

    private void HandleClientStartEvent()
    {
        NetworkManager.Singleton.StartClient();
    }

    private void HandleHostStartEvent()
    {
        NetworkManager.Singleton.StartHost();
        NetworkManager.Singleton.SceneManager.LoadScene("GameScene", UnityEngine.SceneManagement.LoadSceneMode.Single);
    }
}
